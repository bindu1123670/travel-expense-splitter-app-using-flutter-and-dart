// A complete, single-file Flutter application demonstrating the frontend UI structure
// for a Travel Expense Splitter App, focusing on aesthetics and effectiveness.

import 'package:flutter/material.dart';

// --- Custom Colors and Theme ---
const Color primaryTeal = Color(0xFF00BFA5);
const Color accentOrange = Color(0xFFFF9800);
const Color backgroundLight = Color(0xFFF5F5F5);
const Color textDark = Color(0xFF263238);
const Color expenseRed = Color(0xFFE53935);
const Color incomeGreen = Color(0xFF43A047);

void main() {
  runApp(const TravelSplitterApp());
}

// --- Main Application Widget ---
class TravelSplitterApp extends StatelessWidget {
  const TravelSplitterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Trip Mate',
      theme: ThemeData(
        primaryColor: primaryTeal,
        hintColor: accentOrange,
        scaffoldBackgroundColor: backgroundLight,
        fontFamily: 'Inter',
        appBarTheme: const AppBarTheme(
          backgroundColor: primaryTeal,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          selectedItemColor: primaryTeal,
          unselectedItemColor: Colors.grey,
          backgroundColor: Colors.white,
          elevation: 8,
        ),
        cardTheme: CardThemeData(
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(
            vertical: 16.0,
            horizontal: 16.0,
          ),
        ),
        useMaterial3: true,
      ),
      home: const SplashScreen(), // Start at the Splash Screen
    );
  }
}

// 0. Splash Screen
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    // Simulate loading time and navigate to Login/Signup
    Future.delayed(const Duration(seconds: 4), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const LoginScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: primaryTeal,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.luggage_rounded, size: 80, color: Colors.white),
            SizedBox(height: 16),
            Text(
              'Trip Mate',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 8),
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(accentOrange),
            ),
          ],
        ),
      ),
    );
  }
}

// 1. Login Screen
class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryTeal,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(
                Icons.flight_takeoff_rounded,
                size: 80,
                color: Colors.white,
              ),
              const SizedBox(height: 24),
              const Text(
                'Welcome Back',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 32),

              // Email Field
              const TextField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'Email Address',
                  prefixIcon: Icon(Icons.email_rounded, color: primaryTeal),
                ),
              ),
              const SizedBox(height: 16),

              // Password Field
              const TextField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Password',
                  prefixIcon: Icon(Icons.lock_rounded, color: primaryTeal),
                ),
              ),
              const SizedBox(height: 32),

              // Login Button
              ElevatedButton(
                onPressed: () {
                  // Simulate successful login and navigate to MainScaffold
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(
                      builder: (context) => const MainScaffold(),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentOrange,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Log In',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Signup Button Link
              TextButton(
                onPressed: () {
                  // Navigate to the new SignupScreen
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const SignupScreen(),
                    ),
                  );
                },
                child: const Text(
                  "Don't have an account? Sign Up",
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// 1b. Signup Screen (NEW)
class SignupScreen extends StatelessWidget {
  const SignupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryTeal,
      appBar: AppBar(
        // Transparent AppBar for clean full-screen look, matching the background color
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(
                Icons.person_add_rounded,
                size: 80,
                color: Colors.white,
              ),
              const SizedBox(height: 24),
              const Text(
                'Create Your Account',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 32),

              // Name Field
              const TextField(
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                  hintText: 'Full Name',
                  prefixIcon: Icon(Icons.person_rounded, color: primaryTeal),
                ),
              ),
              const SizedBox(height: 16),

              // Email Field
              const TextField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  hintText: 'Email Address',
                  prefixIcon: Icon(Icons.email_rounded, color: primaryTeal),
                ),
              ),
              const SizedBox(height: 16),

              // Password Field
              const TextField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Password',
                  prefixIcon: Icon(Icons.lock_rounded, color: primaryTeal),
                ),
              ),
              const SizedBox(height: 16),

              // Confirm Password Field
              const TextField(
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'Confirm Password',
                  prefixIcon: Icon(Icons.lock_open_rounded, color: primaryTeal),
                ),
              ),
              const SizedBox(height: 32),

              // Sign Up Button
              ElevatedButton(
                onPressed: () {
                  // Simulate successful registration and navigate to MainScaffold
                  _showSnackbar(context, 'Account created successfully!');
                  Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(
                      builder: (context) => const MainScaffold(),
                    ),
                    (Route<dynamic> route) => false,
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: accentOrange,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: const Text(
                  'Sign Up',
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Login Link
              TextButton(
                onPressed: () {
                  // Navigate back to the Login Screen
                  Navigator.of(context).pop();
                },
                child: const Text(
                  "Already have an account? Log In",
                  style: TextStyle(color: Colors.white70),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// --- Main Navigation Shell (Handles Bottom Navigation Bar) ---
class MainScaffold extends StatefulWidget {
  const MainScaffold({super.key});

  @override
  State<MainScaffold> createState() => _MainScaffoldState();
}

class _MainScaffoldState extends State<MainScaffold> {
  int _currentIndex = 0;

  // List of screens corresponding to the BottomNavigationBar items
  final List<Widget> _screens = [
    const HomeScreen(),
    const DestinationListScreen(),
    const ItineraryPlannerScreen(),
    const ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed, // Ensure all icons are visible
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard_rounded),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.travel_explore_rounded),
            label: 'Trips',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month_rounded),
            label: 'Itinerary',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

// --- 2. Home Screen (Categories/Dashboard) ---
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Tripmate',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () {
              // Navigate to the Search Screen
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => const SearchScreen()),
              );
            },
          ),
          IconButton(
            icon: const Icon(Icons.notifications_rounded),
            onPressed: () {
              // Notifications stub
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Current Trip Summary Card
            const CurrentTripSummaryCard(),
            const SizedBox(height: 24),

            // Expense Categories Grid
            const Text(
              'Expense Categories',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 12),
            const ExpenseCategoryGrid(),

            const SizedBox(height: 24),

            // Quick Actions
            const Text(
              'Quick Actions',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                QuickActionButton(
                  icon: Icons.add_circle_outline,
                  label: 'Add Expense',
                  color: primaryTeal,
                  onTap: () {
                    // Navigate to the dedicated AddExpenseScreen
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const AddExpenseScreen(),
                      ),
                    );
                  },
                ),
                QuickActionButton(
                  icon: Icons.account_balance_wallet_outlined,
                  label: 'Settle Debts',
                  color: accentOrange,
                  onTap: () {
                    _showSnackbar(
                      context,
                      'Settle Debts functionality triggered.',
                    );
                  },
                ),
                QuickActionButton(
                  icon: Icons.favorite_border_rounded,
                  label: 'Favorites',
                  color: Colors.pinkAccent,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) => const FavoritesScreen(),
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// Custom Widget for Home Screen Trip Summary
class CurrentTripSummaryCard extends StatelessWidget {
  const CurrentTripSummaryCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: primaryTeal,
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Current Trip: Paris Adventure',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Total Spent: \$1,250.50 / \$2,500.00',
              style: TextStyle(fontSize: 16, color: Colors.white70),
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: 1250.50 / 2500.00,
              backgroundColor: Colors.white30,
              valueColor: const AlwaysStoppedAnimation<Color>(accentOrange),
              borderRadius: BorderRadius.circular(8),
              minHeight: 10,
            ),
            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () {
                  // Navigate to the Destination Detail Screen
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => const DestinationDetailScreen(
                        tripName: 'Paris Adventure',
                      ),
                    ),
                  );
                },
                child: const Text(
                  'View Details >',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Custom Widget for Expense Category Grid
class ExpenseCategoryGrid extends StatelessWidget {
  const ExpenseCategoryGrid({super.key});

  final List<Map<String, dynamic>> categories = const [
    {'name': 'Food', 'icon': Icons.fastfood_rounded, 'color': expenseRed},
    {
      'name': 'Transport',
      'icon': Icons.directions_bus_rounded,
      'color': Colors.blueAccent,
    },
    {
      'name': 'Lodging',
      'icon': Icons.hotel_rounded,
      'color': Colors.purpleAccent,
    },
    {
      'name': 'Activities',
      'icon': Icons.attractions_rounded,
      'color': accentOrange,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        childAspectRatio: 1.5,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        final category = categories[index];
        return CategoryCard(
          icon: category['icon'],
          label: category['name'],
          color: category['color'],
        );
      },
    );
  }
}

// Card for individual categories
class CategoryCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;

  const CategoryCard({
    super.key,
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          _showSnackbar(context, 'Filtering by $label category.');
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(icon, size: 32, color: color),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: textDark,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Custom Widget for Quick Actions
class QuickActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const QuickActionButton({
    super.key,
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(50),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: color.withOpacity(0.3), width: 1),
            ),
            child: Icon(icon, size: 28, color: color),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w500,
            color: textDark.withOpacity(0.8),
          ),
        ),
      ],
    );
  }
}

// Helper function to show a temporary message
void _showSnackbar(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message),
      duration: const Duration(milliseconds: 1500),
    ),
  );
}

// --- 3. Destination List Screen ---
class DestinationListScreen extends StatelessWidget {
  const DestinationListScreen({super.key});

  final List<Map<String, dynamic>> trips = const [
    {
      'name': 'Paris Adventure',
      'dates': 'Oct 1 - Oct 7',
      'members': 4,
      'budget': 2500,
      'spent': 1250.50,
      'image': 'https://placehold.co/600x400/00BFA5/FFFFFF?text=Paris',
    },
    {
      'name': 'Bali Relaxation',
      'dates': 'Nov 15 - Nov 22',
      'members': 2,
      'budget': 3000,
      'spent': 800.25,
      'image': 'https://placehold.co/600x400/FF9800/FFFFFF?text=Bali',
    },
    {
      'name': 'Tokyo Food Tour',
      'dates': 'Dec 1 - Dec 10',
      'members': 3,
      'budget': 4000,
      'spent': 3500.00,
      'image': 'https://placehold.co/600x400/263238/FFFFFF?text=Tokyo',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'My Trips',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: trips.length,
        itemBuilder: (context, index) {
          final trip = trips[index];
          return DestinationCard(
            trip: trip,
            onTap: () {
              // Navigate to Destination Detail Screen
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) =>
                      DestinationDetailScreen(tripName: trip['name']),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // Navigate to the new NewTripScreen
          Navigator.of(context).push(
            MaterialPageRoute(builder: (context) => const NewTripScreen()),
          );
        },
        icon: const Icon(Icons.add_rounded, color: Colors.white),
        label: const Text('New Trip', style: TextStyle(color: Colors.white)),
        backgroundColor: accentOrange,
      ),
    );
  }
}

// Custom Widget for Destination List Card
class DestinationCard extends StatelessWidget {
  final Map<String, dynamic> trip;
  final VoidCallback onTap;

  const DestinationCard({super.key, required this.trip, required this.onTap});

  @override
  Widget build(BuildContext context) {
    // Calculate progress for the budget bar
    final progress = trip['spent'] / trip['budget'];

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      clipBehavior:
          Clip.antiAlias, // Ensures the image respects the rounded corners
      child: InkWell(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Placeholder Image (Simulated Header)
            Image.network(
              trip['image'],
              height: 140,
              width: double.infinity,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) => Container(
                height: 140,
                color: primaryTeal.withOpacity(0.2),
                child: Center(
                  child: Text(
                    trip['name'],
                    style: const TextStyle(fontSize: 24, color: textDark),
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    trip['name'],
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: textDark,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        trip['dates'],
                        style: TextStyle(color: textDark.withOpacity(0.7)),
                      ),
                      Row(
                        children: [
                          const Icon(
                            Icons.group_rounded,
                            size: 16,
                            color: primaryTeal,
                          ),
                          const SizedBox(width: 4),
                          Text('${trip['members']} Members'),
                        ],
                      ),
                    ],
                  ),
                  const Divider(height: 24),

                  // Budget Bar and Summary
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Spent: \$${trip['spent'].toStringAsFixed(2)}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                      Text(
                        'Budget: \$${trip['budget'].toStringAsFixed(2)}',
                        style: TextStyle(
                          color: expenseRed,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: progress,
                    backgroundColor: backgroundLight,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      progress > 0.8
                          ? expenseRed
                          : primaryTeal, // Red if over 80%
                    ),
                    borderRadius: BorderRadius.circular(10),
                    minHeight: 8,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- 4. Destination Detail Screen (Full Implementation) ---
class DestinationDetailScreen extends StatelessWidget {
  final String tripName;

  const DestinationDetailScreen({super.key, required this.tripName});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            tripName,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.location_on_rounded),
              onPressed: () {
                // Navigate to Map View
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (context) => const MapViewScreen(),
                  ),
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.edit_rounded),
              onPressed: () {
                _showSnackbar(context, 'Editing trip details.');
              },
            ),
          ],
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
            indicatorColor: accentOrange,
            tabs: [
              Tab(text: 'Overview', icon: Icon(Icons.info_outline)),
              Tab(text: 'Expenses', icon: Icon(Icons.receipt_long_rounded)),
              Tab(text: 'People', icon: Icon(Icons.group_rounded)),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            _DetailOverviewTab(),
            _DetailExpensesTab(),
            _DetailPeopleTab(),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () {
            // Navigate to the dedicated AddExpenseScreen
            Navigator.of(context).push(
              MaterialPageRoute(builder: (context) => const AddExpenseScreen()),
            );
          },
          icon: const Icon(Icons.add_rounded, color: Colors.white),
          label: const Text(
            'Add Expense',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: primaryTeal,
        ),
      ),
    );
  }
}

// Sub-Tab 1: Trip Overview
class _DetailOverviewTab extends StatelessWidget {
  const _DetailOverviewTab();

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Trip Balance Summary',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: textDark,
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            color: incomeGreen,
            child: Padding(
              padding: EdgeInsets.all(20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'You are owed:',
                    style: TextStyle(fontSize: 18, color: Colors.white),
                  ),
                  Text(
                    '\$125.00',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),

          const Text(
            'Key Statistics',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: textDark,
            ),
          ),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              _StatCard(
                icon: Icons.calendar_today_rounded,
                label: 'Days Left',
                value: '3',
              ),
              _StatCard(
                icon: Icons.attach_money_rounded,
                label: 'Avg Daily Spend',
                value: '\$178.64',
              ),
              _StatCard(
                icon: Icons.group_add_rounded,
                label: 'Total Members',
                value: '4',
              ),
              _StatCard(
                icon: Icons.receipt_long_rounded,
                label: 'Total Expenses',
                value: '18',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _StatCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 32, color: primaryTeal),
            const SizedBox(height: 8),
            Text(
              value,
              style: const TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: const TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

// Sub-Tab 2: Expenses List
class _DetailExpensesTab extends StatelessWidget {
  const _DetailExpensesTab();

  final List<Map<String, dynamic>> expenses = const [
    {
      'item': 'Dinner at Eiffel Tower',
      'amount': 180.00,
      'paidBy': 'Jane',
      'category': 'Food',
    },
    {
      'item': 'Train Tickets',
      'amount': 55.50,
      'paidBy': 'You',
      'category': 'Transport',
    },
    {
      'item': 'Museum Entry',
      'amount': 120.00,
      'paidBy': 'John',
      'category': 'Activities',
    },
    {
      'item': 'Hotel Day 1',
      'amount': 300.00,
      'paidBy': 'You',
      'category': 'Lodging',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: expenses.length,
      itemBuilder: (context, index) {
        final expense = expenses[index];
        final isPaidByYou = expense['paidBy'] == 'You';

        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: primaryTeal.withOpacity(0.1),
              child: Icon(
                _getIconForCategory(expense['category']),
                color: primaryTeal,
              ),
            ),
            title: Text(
              expense['item'],
              style: const TextStyle(fontWeight: FontWeight.w600),
            ),
            subtitle: Text('Paid by: ${expense['paidBy']}'),
            trailing: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '-\$${expense['amount'].toStringAsFixed(2)}',
                  style: TextStyle(
                    color: expenseRed,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                Text(
                  isPaidByYou
                      ? 'You owe \$0.00'
                      : 'You owe \$45.00', // Example split
                  style: TextStyle(
                    fontSize: 12,
                    color: isPaidByYou ? incomeGreen : expenseRed,
                  ),
                ),
              ],
            ),
            onTap: () {
              _showSnackbar(context, 'Viewing details for ${expense['item']}.');
            },
          ),
        );
      },
    );
  }

  IconData _getIconForCategory(String category) {
    switch (category) {
      case 'Food':
        return Icons.fastfood_rounded;
      case 'Transport':
        return Icons.directions_bus_rounded;
      case 'Lodging':
        return Icons.hotel_rounded;
      case 'Activities':
        return Icons.attractions_rounded;
      default:
        return Icons.receipt_long_rounded;
    }
  }
}

// Sub-Tab 3: People/Splitting Summary
class _DetailPeopleTab extends StatelessWidget {
  const _DetailPeopleTab();

  final List<Map<String, dynamic>> people = const [
    {'name': 'Jane Doe', 'balance': 125.00, 'isOwed': true},
    {'name': 'John Smith', 'balance': -50.00, 'isOwed': false},
    {'name': 'Alex Lee', 'balance': -75.00, 'isOwed': false},
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16.0),
      children: [
        const Text(
          'Group Members',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: textDark,
          ),
        ),
        const SizedBox(height: 12),
        ...people.map((person) {
          final color = person['isOwed'] ? incomeGreen : expenseRed;
          final prefix = person['isOwed'] ? 'Is owed' : 'Owes';

          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: color.withOpacity(0.2),
                child: Text(
                  person['name'][0],
                  style: TextStyle(color: color, fontWeight: FontWeight.bold),
                ),
              ),
              title: Text(
                person['name'],
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              subtitle: Text(prefix),
              trailing: Text(
                '\$${person['balance'].abs().toStringAsFixed(2)}',
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              onTap: () {
                _showSnackbar(
                  context,
                  'Viewing settlement options for ${person['name']}.',
                );
              },
            ),
          );
        }).toList(),
      ],
    );
  }
}

// --- 5. Map View Screen ---
class MapViewScreen extends StatelessWidget {
  const MapViewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Trip Map View',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 250,
              width: 250,
              decoration: BoxDecoration(
                color: backgroundLight,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: primaryTeal, width: 4),
              ),
              child: const Icon(
                Icons.map_rounded,
                size: 100,
                color: primaryTeal,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Interactive Map of Trip Locations',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w600,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Show pin drops for expenses and itinerary points.',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

// --- 6. Favorites Screen ---
class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  final List<String> favoritePlaces = const [
    'The Louvre, Paris',
    'Ubud Monkey Forest, Bali',
    'Shibuya Crossing, Tokyo',
    'Ristorante Pesto, Rome',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Favorite Places',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.pinkAccent,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: favoritePlaces.length,
        itemBuilder: (context, index) {
          return Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: const Icon(
                Icons.favorite_rounded,
                color: Colors.pinkAccent,
              ),
              title: Text(
                favoritePlaces[index],
                style: const TextStyle(fontWeight: FontWeight.w500),
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () {
                _showSnackbar(
                  context,
                  'Navigating to ${favoritePlaces[index]} map location.',
                );
              },
            ),
          );
        },
      ),
    );
  }
}

// --- 7. Itinerary Planner Screen ---
class ItineraryPlannerScreen extends StatelessWidget {
  const ItineraryPlannerScreen({super.key});

  final List<Map<String, String>> itineraryItems = const [
    {'time': 'Day 1: 10:00 AM', 'activity': 'Eiffel Tower Visit'},
    {'time': 'Day 1: 01:00 PM', 'activity': 'Lunch near the Seine'},
    {'time': 'Day 2: 09:00 AM', 'activity': 'Louvre Museum Tour'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Itinerary Planner',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text(
            'Paris Adventure Schedule',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: textDark,
            ),
          ),
          const SizedBox(height: 12),
          ...itineraryItems.map(
            (item) =>
                ItineraryTile(time: item['time']!, activity: item['activity']!),
          ),
          const SizedBox(height: 20),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _showSnackbar(context, 'Add new itinerary item.');
        },
        backgroundColor: primaryTeal,
        child: const Icon(Icons.add_rounded, color: Colors.white),
      ),
    );
  }
}

class ItineraryTile extends StatelessWidget {
  final String time;
  final String activity;

  const ItineraryTile({super.key, required this.time, required this.activity});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: const Icon(
          Icons.access_time_filled_rounded,
          color: accentOrange,
        ),
        title: Text(
          activity,
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(time),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () {
          _showSnackbar(context, 'Viewing itinerary for $activity.');
        },
      ),
    );
  }
}

// --- 8. Search Screen ---
class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: backgroundLight,
        iconTheme: const IconThemeData(color: textDark),
        title: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: const TextField(
            decoration: InputDecoration(
              hintText: 'Search trips, expenses, or places...',
              prefixIcon: Icon(Icons.search_rounded, color: primaryTeal),
              border: InputBorder.none,
              contentPadding: EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Recent Searches',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 12),
            _RecentSearchItem(label: 'Tokyo Food Tour Expenses'),
            _RecentSearchItem(label: 'John Smith Balance'),
            _RecentSearchItem(label: 'Lodging category in Bali'),
            const SizedBox(height: 24),
            const Text(
              'Trending Destinations',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const Wrap(
              spacing: 8.0,
              runSpacing: 4.0,
              children: [
                _SearchTag(label: 'Rome'),
                _SearchTag(label: 'Thailand'),
                _SearchTag(label: 'Splitwise'),
                _SearchTag(label: 'Group Budget'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _RecentSearchItem extends StatelessWidget {
  final String label;

  const _RecentSearchItem({required this.label});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.history_rounded, color: Colors.grey),
      title: Text(label),
      trailing: const Icon(
        Icons.north_west_rounded,
        size: 16,
        color: Colors.grey,
      ),
      onTap: () {
        _showSnackbar(context, 'Searching for "$label"');
      },
    );
  }
}

class _SearchTag extends StatelessWidget {
  final String label;

  const _SearchTag({required this.label});

  @override
  Widget build(BuildContext context) {
    return Chip(
      label: Text(label),
      backgroundColor: primaryTeal.withOpacity(0.1),
      labelStyle: const TextStyle(color: primaryTeal),
    );
  }
}

// --- 9. Profile/Settings Screen ---
class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile & Settings',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: const [
          // User Header
          ProfileHeader(),
          Divider(height: 32),

          // Settings Options
          SettingsTile(icon: Icons.edit_rounded, title: 'Edit Profile'),
          SettingsTile(
            icon: Icons.security_rounded,
            title: 'Privacy & Security',
          ),
          SettingsTile(
            icon: Icons.currency_exchange_rounded,
            title: 'Currency Settings',
          ),
          SettingsTile(
            icon: Icons.notifications_active_rounded,
            title: 'Notification Preferences',
          ),
          SettingsTile(
            icon: Icons.help_outline_rounded,
            title: 'Help & Support',
          ),
          SettingsTile(
            icon: Icons.logout_rounded,
            title: 'Logout',
            isDestructive: true,
          ),
        ],
      ),
    );
  }
}

// Custom Widget for Profile Header
class ProfileHeader extends StatelessWidget {
  const ProfileHeader({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        CircleAvatar(
          radius: 40,
          backgroundColor: primaryTeal,
          child: Text(
            'JD',
            style: const TextStyle(
              fontSize: 32,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 16),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Jane Doe',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            SizedBox(height: 4),
            Text(
              'janedoe@travelsplitter.com',
              style: TextStyle(fontSize: 14, color: Colors.grey),
            ),
          ],
        ),
      ],
    );
  }
}

// Custom Widget for Settings Tile
class SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool isDestructive;

  const SettingsTile({
    super.key,
    required this.icon,
    required this.title,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? expenseRed : textDark;

    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(
        title,
        style: TextStyle(color: color, fontWeight: FontWeight.w500),
      ),
      trailing: const Icon(Icons.chevron_right_rounded, color: Colors.grey),
      onTap: () {
        _showSnackbar(context, 'Navigating to $title settings.');

        // For Logout, navigate back to the Login Screen
        if (isDestructive) {
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (context) => const LoginScreen()),
            (Route<dynamic> route) => false,
          );
        }
      },
    );
  }
}

// --- New: Add Expense Screen ---
class AddExpenseScreen extends StatefulWidget {
  const AddExpenseScreen({super.key});

  @override
  State<AddExpenseScreen> createState() => _AddExpenseScreenState();
}

class _AddExpenseScreenState extends State<AddExpenseScreen> {
  String? _selectedCategory;
  String? _paidBy;
  final List<String> categories = [
    'Food',
    'Transport',
    'Lodging',
    'Activities',
    'Other',
  ];
  final List<String> members = ['You', 'Jane Doe', 'John Smith', 'Alex Lee'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Add New Expense',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Amount Input
            const Text(
              'Amount',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            const TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: '0.00',
                prefixIcon: Icon(
                  Icons.attach_money_rounded,
                  color: primaryTeal,
                ),
                fillColor: Colors.white,
              ),
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 24),

            // Description Input
            const Text(
              'Description',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            const TextField(
              decoration: InputDecoration(
                hintText: 'What was this expense for?',
                prefixIcon: Icon(Icons.description_rounded, color: primaryTeal),
                fillColor: Colors.white,
              ),
            ),
            const SizedBox(height: 24),

            // Category Dropdown
            _buildDropdownField(
              context,
              'Category',
              Icons.category_rounded,
              _selectedCategory,
              categories,
              (newValue) => setState(() => _selectedCategory = newValue),
            ),
            const SizedBox(height: 24),

            // Paid By Dropdown
            _buildDropdownField(
              context,
              'Paid By',
              Icons.person_rounded,
              _paidBy,
              members,
              (newValue) => setState(() => _paidBy = newValue),
            ),
            const SizedBox(height: 24),

            // Split Details (Simplified for UI)
            const Text(
              'Split Details',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.call_split_rounded,
                  color: accentOrange,
                ),
                title: const Text('Split equally among 4 people'),
                subtitle: const Text('You owe \$45.00'),
                trailing: const Icon(Icons.edit_rounded),
                onTap: () {
                  _showSnackbar(context, 'Advanced split editor opened.');
                },
              ),
            ),
            const SizedBox(height: 40),

            // Save Button
            ElevatedButton(
              onPressed: () {
                _showSnackbar(context, 'Expense added successfully!');
                // Typically you would save data here, then pop the screen.
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryTeal,
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Save Expense',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdownField(
    BuildContext context,
    String label,
    IconData icon,
    String? currentValue,
    List<String> items,
    Function(String?) onChanged,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: textDark,
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(
            horizontal: 0.0,
          ), // Padding adjusted for Dropdown
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 1,
                blurRadius: 3,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: DropdownButtonFormField<String>(
            decoration: InputDecoration(
              prefixIcon: Icon(icon, color: primaryTeal),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                vertical: 16.0,
                horizontal: 8.0,
              ),
              filled:
                  false, // Override theme setting for cleaner dropdown integration
            ),
            value: currentValue,
            hint: Text('Select $label'),
            isExpanded: true,
            items: items.map<DropdownMenuItem<String>>((String value) {
              return DropdownMenuItem<String>(value: value, child: Text(value));
            }).toList(),
            onChanged: onChanged,
          ),
        ),
      ],
    );
  }
}

// --- New: New Trip Screen ---
class NewTripScreen extends StatefulWidget {
  const NewTripScreen({super.key});

  @override
  State<NewTripScreen> createState() => _NewTripScreenState();
}

class _NewTripScreenState extends State<NewTripScreen> {
  DateTime? _startDate;
  DateTime? _endDate;

  Future<void> _selectDate(BuildContext context, bool isStart) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: primaryTeal,
            colorScheme: ColorScheme.light(
              primary: primaryTeal,
              secondary: accentOrange,
            ),
            buttonTheme: const ButtonThemeData(
              textTheme: ButtonTextTheme.primary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        if (isStart) {
          _startDate = picked;
          if (_endDate != null && _startDate!.isAfter(_endDate!)) {
            _endDate = _startDate; // Ensure end date is not before start date
          }
        } else {
          _endDate = picked;
          if (_startDate != null && _endDate!.isBefore(_startDate!)) {
            _startDate = _endDate; // Ensure start date is not after end date
          }
        }
      });
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Select Date';
    return '${date.month}/${date.day}/${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Plan New Trip',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Trip Name
            const Text(
              'Trip Name',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            const TextField(
              decoration: InputDecoration(
                hintText: 'e.g., European Backpacking Tour',
                prefixIcon: Icon(Icons.luggage_rounded, color: primaryTeal),
              ),
            ),
            const SizedBox(height: 24),

            // Destination
            const Text(
              'Destination',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            const TextField(
              decoration: InputDecoration(
                hintText: 'e.g., Rome, Italy',
                prefixIcon: Icon(Icons.location_on_rounded, color: primaryTeal),
              ),
            ),
            const SizedBox(height: 24),

            // Dates Selector
            const Text(
              'Travel Dates',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DateSelector(
                    label: 'Start Date',
                    date: _formatDate(_startDate),
                    onTap: () => _selectDate(context, true),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: DateSelector(
                    label: 'End Date',
                    date: _formatDate(_endDate),
                    onTap: () => _selectDate(context, false),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Budget
            const Text(
              'Total Budget (Optional)',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 8),
            const TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: '2000.00',
                prefixIcon: Icon(
                  Icons.attach_money_rounded,
                  color: primaryTeal,
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Members (Simplified for UI)
            const Text(
              'Initial Members',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: textDark,
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.group_add_rounded,
                  color: accentOrange,
                ),
                title: const Text('Add Group Members'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () {
                  _showSnackbar(context, 'Member selection interface opened.');
                },
              ),
            ),
            const SizedBox(height: 40),

            // Create Trip Button
            ElevatedButton(
              onPressed: () {
                _showSnackbar(context, 'Trip created and saved!');
                // Navigate back to the DestinationListScreen
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: accentOrange,
                minimumSize: const Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: const Text(
                'Create Trip',
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Custom widget for date selection button
class DateSelector extends StatelessWidget {
  final String label;
  final String date;
  final VoidCallback onTap;

  const DateSelector({
    super.key,
    required this.label,
    required this.date,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontSize: 14, color: Colors.grey)),
        const SizedBox(height: 4),
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 16.0,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade300),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  date,
                  style: const TextStyle(
                    fontSize: 16,
                    color: textDark,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Icon(
                  Icons.calendar_today_rounded,
                  size: 20,
                  color: primaryTeal,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// --- Stub Widgets (Now fully integrated into navigation) ---
class FavoritesScreenStub extends StatelessWidget {
  const FavoritesScreenStub({super.key});
  @override
  Widget build(BuildContext context) => const Placeholder();
}

class SearchScreenStub extends StatelessWidget {
  const SearchScreenStub({super.key});
  @override
  Widget build(BuildContext context) => const Placeholder();
}
